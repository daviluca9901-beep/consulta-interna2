"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface WelcomeScreenProps {
  onAccessDashboard: (name: string) => void
}

export function WelcomeScreen({ onAccessDashboard }: WelcomeScreenProps) {
  const [name, setName] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onAccessDashboard(name)
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md space-y-8 text-center">
        <div className="space-y-4">
          <h1 className="text-3xl font-semibold tracking-tight text-foreground sm:text-4xl text-balance">
            Bem-vindo a Plataforma de Ferramentas Internas
          </h1>
          <p className="text-muted-foreground text-base sm:text-lg">
            Para acessar as funcionalidades, informe seu nome completo abaixo
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 mt-8">
          <div className="space-y-2 text-left">
            <Label htmlFor="fullName" className="text-sm font-medium text-foreground">
              Nome completo
            </Label>
            <Input
              id="fullName"
              type="text"
              placeholder="Digite seu nome completo"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 text-base bg-card border-border focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
              autoComplete="name"
            />
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full h-12 text-base font-medium bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
          >
            Acessar Dashboard
          </Button>
        </form>
      </div>
    </div>
  )
}
