"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

interface DashboardProps {
  userName: string
}

type ProcessState = "idle" | "processing" | "complete"

export function Dashboard({ userName }: DashboardProps) {
  const [inputValue, setInputValue] = useState("")
  const [processState, setProcessState] = useState<ProcessState>("idle")

  const handleStartProcess = (e: React.FormEvent) => {
    e.preventDefault()
    setProcessState("processing")
    
    // Simula processamento de 3-5 segundos
    const processingTime = 3000 + Math.random() * 2000
    setTimeout(() => {
      setProcessState("complete")
    }, processingTime)
  }

  const handleReset = () => {
    setProcessState("idle")
    setInputValue("")
  }

  return (
    <div className="min-h-screen px-4 py-8 sm:py-12">
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Header */}
        <header className="space-y-2">
          <p className="text-sm text-muted-foreground">
            Bem-vindo, {userName || "Usuario"}
          </p>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
            Ferramentas Disponiveis
          </h1>
        </header>

        {/* Main Form Card */}
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-6 sm:p-8">
            <form onSubmit={handleStartProcess} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="processInput" className="text-sm font-medium text-foreground">
                  Digite a informacao para prosseguir
                </Label>
                <Input
                  id="processInput"
                  type="text"
                  placeholder="Insira a informacao aqui"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  disabled={processState === "processing"}
                  className="h-12 text-base bg-background border-border focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all disabled:opacity-50"
                />
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={processState === "processing"}
                className="w-full h-12 text-base font-medium bg-primary hover:bg-primary/90 text-primary-foreground transition-colors disabled:opacity-70"
              >
                {processState === "processing" ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Processando...
                  </>
                ) : (
                  "Iniciar Processo"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Result Section */}
        <Card className="border-border bg-card shadow-sm">
          <CardContent className="p-6 sm:p-8">
            {processState === "idle" && (
              <div className="text-center py-4">
                <p className="text-muted-foreground">
                  Resultado sera exibido aqui apos processamento
                </p>
              </div>
            )}

            {processState === "processing" && (
              <div className="text-center py-4 space-y-4">
                <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
                <p className="text-foreground font-medium">
                  Processando solicitacao...
                </p>
                <p className="text-sm text-muted-foreground">
                  Por favor, aguarde enquanto processamos sua solicitacao
                </p>
              </div>
            )}

            {processState === "complete" && (
              <div className="text-center py-4 space-y-4">
                <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center mx-auto">
                  <svg
                    className="w-6 h-6 text-primary"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </div>
                <div className="space-y-2">
                  <p className="text-foreground font-medium">
                    Processo iniciado com sucesso
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Aguarde atualizacoes ou tente novamente se necessario.
                  </p>
                </div>
                <Button
                  variant="outline"
                  onClick={handleReset}
                  className="mt-4 border-border hover:bg-accent hover:text-accent-foreground transition-colors bg-transparent"
                >
                  Nova Solicitacao
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
